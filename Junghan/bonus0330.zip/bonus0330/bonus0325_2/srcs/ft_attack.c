/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_attack.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: junghan <junghan@student.42seoul.kr>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/03/26 05:45:47 by junghan           #+#    #+#             */
/*   Updated: 2021/03/26 07:17:19 by junghan          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cub3d.h"

int		attack_sp(t_info *info, t_sprite *s, int tex)
{
	int st;
	int y;

	st = s->drawstart_x - 1;
	while (++st < s->drawend_x && tex != 0)
	{
		if (s->transf_y > 0 && st > 0 && st < info->win_wid &&
				s->transf_y < info->z_buffer[st])
		{
			y = s->drawstart_y - 1;
			while (++y < s->drawend_y)
			{
				if (info->skill_t != 0 && st == info->win_wid / 2 &&
						y == info->win_hei / 2)
				//	if ((s->color != -16777216))
						return (1);
			}
		}
	}
	return (0);
}

void	sp_or_dam(t_info *info, t_sprite *s, int tex)
{
	if (attack_sp(info, s, tex) && tex == 10)
		;
	else
		put_in_spritebuf(s, info, tex);
}

void	attack(t_info *info, t_img *img, char *path)
{
	int		x;
	int		y;

	img->img = mlx_xpm_file_to_image(info->mlx,
			path, &img->img_width, &img->img_height);
	img->data = (int *)mlx_get_data_addr(img->img,
			&img->bpp, &img->size_l, &img->endian);
	tex_wh(info, 16, img);
	y = -1;
	while (++y < img->img_height)
	{
		x = -1;
		while (++x < img->img_width)
			info->texture[16][img->img_width * y + x] =
				img->data[img->img_width * y + x];
	}
	mlx_destroy_image(info->mlx, img->img);
	info->skill_t++;
	if (info->skill_t == 12)
	{
		info->skill1 = 0;
		info->skill_t = 0;
	}
	put_in_weapon(info, img, 16);
}

int			click_r(int b, int x, int y, t_info *info)
{
	x = 0;
	y = 0;
	if (b == 0)
		info->skill1 = 0;
	return (0);
}

int			click(int b, int x, int y, t_info *info)
{
	x = 0;
	y = 0;
	if (b == 1 && info->keys.key_p == 1)
		info->skill1 = 1;
	return (0);
}
