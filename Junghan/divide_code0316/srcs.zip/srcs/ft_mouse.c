/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_mouse.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: junghan <junghan@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/03/10 05:53:47 by junghan           #+#    #+#             */
/*   Updated: 2021/03/11 03:49:18 by junghan          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cub3d.h"

int		mouse_move(int x, int y, t_info *info)
{
	if (info->keys.key_p == 1)
	{
		mlx_mouse_hide();
		info->mou_lr = (x - info->keys.zero_p) / 15;
		if (info->mou_lr < 0)
		{
			turn_left(info, &info->keys);
			mlx_mouse_move(info->win, info->win_wid / 2, info->win_hei / 2);
		}
		if (info->mou_lr > 0)
		{
			turn_right(info, &info->keys);
			mlx_mouse_move(info->win, info->win_wid / 2, info->win_hei / 2);
		}
	}
	mlx_mouse_show();
	return (0);
}
