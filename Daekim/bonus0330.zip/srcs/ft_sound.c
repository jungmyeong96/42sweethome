/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sound.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: junghan <junghan@student.42seoul.kr>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/03/29 23:48:22 by junghan           #+#    #+#             */
/*   Updated: 2021/03/30 04:46:37 by junghan          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cub3d.h"

void	death_sound(t_info * info, int tex)
{
	if (tex == 10 && info->stage_end == 0)
		system("afplay ../sound/madth.wav &");
	if (tex == 10 && info->stage_end == 1)
		system("afplay ../sound/hydth.wav &");
	if (tex == 10 && info->stage_end == 2)
		system("afplay ../sound/dradth.wav &");
	if (tex == 14 && info->stage_end == 0)
		system("afplay ../sound/scvdth.wav &");
	if (tex == 14 && info->stage_end == 1)
		system("afplay ../sound/eggdth.wav &");
	if (tex == 14 && info->stage_end == 2)
		system("afplay ../sound/interdth.wav &");
	if (tex == 15 && info->stage_end == 0)
		system("afplay ../sound/ghostdth.wav &");
	if (tex == 15 && info->stage_end == 1)
		system("afplay ../sound/sungdth.wav &");
	if (tex == 15 && info->stage_end == 2)
		system("afplay ../sound/carridth.wav &");

}
