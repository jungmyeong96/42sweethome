/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_damaged.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: junghan <junghan@student.42seoul.kr>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/03/30 05:31:42 by junghan           #+#    #+#             */
/*   Updated: 2021/03/30 06:31:25 by junghan          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cub3d.h"

void	sp_damaged(t_info *info, int i)
{
	if((info->sprite_arr[i].tex == 10 || info->sprite_arr[i].tex == 15
				|| info->sprite_arr[i].tex == 14) && info->damaged_t > 50)	
	{
		if ((int)info->pos_x < (int)(info->sprite_arr[i].x + 2) &&
				(int)info->pos_x > (int)(info->sprite_arr[i].x - 2))
		{
			if (((int)info->pos_y < info->sprite_arr[i].y + 2 &&
						(int)info->pos_y > info->sprite_arr[i].y - 2))
			{
		/*		if (info->map[(int)(info->pos_x - info->plane_x * info->keys.move_speed)]
						[(int)(info->pos_y)] != '1' && info->map[(int)(info->pos_x
							- info->plane_x * info->keys.move_speed)][(int)(info->pos_y)] != '2'
						&& info->map[(int)(info->pos_x + info->dir_x * info->keys.move_speed)]
						[(int)(info->pos_y)] != '6' && info->map[(int)(info->pos_x
							+ info->dir_x * info->keys.move_speed)][(int)(info->pos_y)] != '7')
					info->pos_x -= (info->dir_x * info->keys.move_speed) * 10;*/
			info->damage = 1;
			info->damaged_t = 0;
			}
		}
	}
}
